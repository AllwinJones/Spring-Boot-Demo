package com.allwin.first.serviceImpl;

import java.util.List;

//import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.allwin.first.model.Address;
import com.allwin.first.model.Employee;
import com.allwin.first.repo.AddressRepo;
import com.allwin.first.repo.EmployeeRepo;
import com.allwin.first.service.EmployeeService;

@Service("employeeService")
@Transactional
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeRepo empRepo;
	
	@Autowired
	private AddressRepo addRepo;
	
	@Override
	public List<Employee> searchEmployeeServ(String searchText) {
		return empRepo.searchEmployee(searchText);
	}
	
	@Override
	public List<Address> findAllByEmpIdServ(String empId) {
		return addRepo.findAllByEmpId(empId);
	}
	
	@Override
	public int deleteAllByEmpIdServ(String empId) {
		return addRepo.deleteAllByEmpId(empId);
	}
	
	@Override
	public List<Address> searchAddressServ(String searchText) {
		return addRepo.searchAddress(searchText);
	}
	
	@Override
	public Employee findOneByIdServ(String empId) {
		return empRepo.findOneById(empId);
	}
	
}
