package com.allwin.first.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Employee {

	@Id
	private String empId;
	private String empName;
	private String empGender;
	private String empEmail;
	private String empPhone;
	private String empPosition;
	private String lastUpdated;
	
}
