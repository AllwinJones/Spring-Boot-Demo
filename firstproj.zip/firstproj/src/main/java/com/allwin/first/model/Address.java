package com.allwin.first.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

//import org.hibernate.annotations.Cache;
//import org.hibernate.annotations.CacheConcurrencyStrategy;
//import org.springframework.cache.annotation.Cacheable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
/*@javax.persistence.Cacheable
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)*/
public class Address {

	@Id
	private Integer addressId;
	
	@NotEmpty(message="Employee ID should not be empty")
	private String empId;
	
	@NotEmpty(message="Street should not be empty")
	@Size(min=3, message="Street should be atleast 3 characters")
	private String street;
	
	@NotEmpty(message="City should not be empty")
	@Size(min=3, message="City should be atleast 3 characters")
	private String city;
	
	@NotEmpty(message="State should not be empty")
	@Size(min=3, message="State should be atleast 3 characters")
	private String state;
	
	@NotEmpty(message="District should not be empty")
	@Size(min=3, message="District should be atleast 3 characters")
	private String district;
	
	@NotEmpty(message="Pincode should not be empty")
	@Size(min=6, max=6, message="Pincode should be 6 characters")
	private String pincode;
	
	private String lastUpdated;
	
}
