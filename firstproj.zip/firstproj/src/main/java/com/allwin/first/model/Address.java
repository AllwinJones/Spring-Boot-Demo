package com.allwin.first.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Address {

	@Id
	private Integer addressId;
	private String empId;
	private String street;
	private String city;
	private String state;
	private String district;
	private String pincode;
	private String lastUpdated;
	
}
