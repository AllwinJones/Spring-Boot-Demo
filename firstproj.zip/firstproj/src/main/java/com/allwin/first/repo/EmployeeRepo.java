package com.allwin.first.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.allwin.first.model.Employee;

public interface EmployeeRepo extends JpaRepository<Employee, String>{
	
	@Query(value = "SELECT * FROM EMPLOYEE WHERE empid like %?1% or empname like %?1% or empgender like %?1% or empemail like %?1% or empphone like %?1% or empposition like %?1%", nativeQuery = true)
	List<Employee> searchEmployee(String searchText);
	
	@Query(value = "SELECT * FROM EMPLOYEE WHERE empid = ?1", nativeQuery = true)
	Employee findOneById(String empId);
	
}
