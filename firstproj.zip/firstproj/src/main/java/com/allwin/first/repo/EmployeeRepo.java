package com.allwin.first.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.allwin.first.model.Employee;

public interface EmployeeRepo extends JpaRepository<Employee, String>{

	@Query(value = "UPDATE employee SET empName=:empName, empGender=:empGender, empEmail=:empEmail, empPhone=:empPhone, empPosition=:empPosition,  WHERE empId=:empId")
	List<Employee> updateEmployee(@Param("empName") String empName, @Param("empGender") String empGender, @Param("empEmail") String empEmail, @Param("empPhone") String empPhone, @Param("empPosition") String empPosition, @Param("empId") String empId);
	
}
