package com.allwin.first;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstprojApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstprojApplication.class, args);
	}

}
