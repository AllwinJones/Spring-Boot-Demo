package com.allwin.first.exception;

@SuppressWarnings("serial")
public class UpdateEmployeeException  extends Exception{
	public UpdateEmployeeException(String message){
		super(message);
	}
}
