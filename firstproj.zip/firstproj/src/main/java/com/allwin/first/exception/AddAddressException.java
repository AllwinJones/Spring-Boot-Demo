package com.allwin.first.exception;

@SuppressWarnings("serial")
public class AddAddressException  extends Exception{
	public AddAddressException(String message){
		super(message);
	}
}
