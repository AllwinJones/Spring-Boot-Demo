package com.allwin.first.exception;

@SuppressWarnings("serial")
public class DeleteAddressException  extends Exception{
	public DeleteAddressException(String message){
		super(message);
	}
}
