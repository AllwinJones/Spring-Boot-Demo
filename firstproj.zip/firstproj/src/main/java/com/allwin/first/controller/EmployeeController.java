package com.allwin.first.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.allwin.first.model.Address;
import com.allwin.first.model.Employee;
import com.allwin.first.repo.AddressRepo;
import com.allwin.first.repo.EmployeeRepo;
import com.allwin.first.service.EmployeeService;

@Controller
public class EmployeeController 
{
	
	@Autowired
	private EmployeeRepo empRepo;
	
	@Autowired
	private AddressRepo addRepo;
	
	@Autowired
	private EmployeeService servRepo;
	
	/*@ModelAttribute
	public void StaticData(Model m)
	{
		m.addAttribute("company","Infosys");
	}*/
	
	@GetMapping("/")
	public String index(Model m) 
	{
		m.addAttribute("employeeList", empRepo.findAll());
		return "index";
	}
	
	@GetMapping("addEmployee")
	public String addEmployee() 
	{
		return "addEmployee";
	}
	
	@PostMapping("addEmployee")
	public String addEmployee(@RequestParam("empId") String empId, @RequestParam("empName") String empName, @RequestParam("empGender") String empGender, @RequestParam("empEmail") String empEmail, @RequestParam("empPhone") String empPhone, @RequestParam("empPosition") String empPosition, @RequestParam("addressId") Integer addressId, @RequestParam("street") String street, @RequestParam("city") String city, @RequestParam("district") String district, @RequestParam("state") String state, @RequestParam("pincode") String pincode) 
	{
		LocalDateTime localDateTime = LocalDateTime.now();
		Employee emp = new Employee(empId, empName, empGender, empEmail, empPhone, empPosition, localDateTime.toString());
		Address addr = new Address(addressId, empId, street, city, state, district, pincode, localDateTime.toString());
		
		empRepo.save(emp);
		addRepo.save(addr);
		return "redirect:/";
	}
	
	@GetMapping("editEmployee/{empId}")
	public String editEmployee(@PathVariable("empId") String empId, Model m) 
	{
		m.addAttribute("employee", empRepo.getOne(empId));
		return "updateEmployee";
	}
	
	@PostMapping("updateEmployee")
	public String updateEmployee(@RequestParam("empId") String empId, @RequestParam("empName") String empName, @RequestParam("empGender") String empGender, @RequestParam("empEmail") String empEmail, @RequestParam("empPhone") String empPhone, @RequestParam("empPosition") String empPosition) 
	{
		LocalDateTime localDateTime = LocalDateTime.now();
		Employee emp = new Employee(empId, empName, empGender, empEmail, empPhone, empPosition, localDateTime.toString());
		empRepo.save(emp);
		return "redirect:/";
	}
	
	@GetMapping("deleteEmployee/{empId}")
	public String deleteEmployee(@PathVariable("empId") String empId, Model m) 
	{
		m.addAttribute("employee", empRepo.findById(empId));
		empRepo.deleteById(empId);
		servRepo.deleteAllByEmpIdServ(empId);
		return "redirect:/";
	}
	
	@PostMapping("searchEmployee")
	public String searchEmployee(@RequestParam("searchText") String searchText, Model m) 
	{
		List<Employee> empList = servRepo.searchEmployeeServ(searchText);
		List<Address> addrList = servRepo.searchAddressServ(searchText);
		for(int i=0;i<addrList.size();i++) {
			Employee emp = empRepo.getOne(addrList.get(i).getEmpId());
			if(empList.contains(emp) == false) { empList.add(emp); }
		}
		m.addAttribute("employeeList", empList);
		m.addAttribute("searchText", searchText);
		return "index";
	}
	
	@GetMapping("addAddress/{empId}")
	public String addAddress(@PathVariable("empId") String empId, Model m) 
	{
		m.addAttribute("employeeId", empId);
		return "addAddress";
	}
	
	@PostMapping("addAddress")
	public String addAddress(@RequestParam("empId") String empId, @RequestParam("addressId") Integer addressId, @RequestParam("street") String street, @RequestParam("city") String city, @RequestParam("district") String district, @RequestParam("state") String state, @RequestParam("pincode") String pincode) 
	{
		LocalDateTime localDateTime = LocalDateTime.now();
		Address addr = new Address(addressId, empId, street, city, state, district, pincode, localDateTime.toString());
		addRepo.save(addr);
		return "redirect:/";
	}
	
	@GetMapping("viewEmployee/{empId}")
	public String viewEmployee(@PathVariable("empId") String empId, Model m) 
	{
		m.addAttribute("employeeData", empRepo.getOne(empId));
		m.addAttribute("addressData", servRepo.findAllByEmpIdServ(empId));
		return "viewEmployee";
	}
	
}
