package com.allwin.first.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.allwin.first.model.Employee;
import com.allwin.first.repo.EmployeeRepo;
import com.allwin.first.service.EmployeeService;
import com.allwin.first.service.implementation.EmployeeServiceImpl;

@Controller
public class EmployeeController 
{
	
	@Autowired
	private EmployeeRepo repo;
	@Autowired
	private EmployeeServiceImpl impl;
	
	@ModelAttribute
	public void StaticData(Model m)
	{
		m.addAttribute("company","Infosys");
	}
	
	@GetMapping("/")
	public String index() 
	{
		return "index";
	}
	
	@GetMapping("/getEmployees")
	public String getEmployees(Model m) 
	{
		m.addAttribute("employeeList", repo.findAll());
		return "allEmployees";
	}
	
	@PostMapping("addEmployee")
	public String addEmployee(Employee emp) 
	{
		repo.save(emp);
		return "result";
	}
	
	@PostMapping("updateEmployee")
	public String updateEmployee(Employee emp) 
	{
		Employee employee = repo.getOne(emp.getEmpId());
		employee.setEmpName(emp.getEmpName());
		repo.save(employee);
		return "result";
	}
	
}
