package com.allwin.first.service.implementation;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.allwin.first.model.Employee;
import com.allwin.first.repo.EmployeeRepo;
import com.allwin.first.service.EmployeeService;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepo repo;
	
	@Override
	public List<Employee> updateEmployeeDetails(String empName, String empGender, String empEmail, String empPhone,
			String empPosition, String empId) {
		return repo.updateEmployee(empName, empGender, empEmail, empPhone, empPosition, empId);
	}

}
