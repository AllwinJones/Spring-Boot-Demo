package com.allwin.first.service;

import java.util.List;

import com.allwin.first.model.Employee;

public interface EmployeeService {

	public List<Employee> updateEmployeeDetails(String empName, String empGender, String empEmail, String empPhone, String empPosition, String empId);
	
}
