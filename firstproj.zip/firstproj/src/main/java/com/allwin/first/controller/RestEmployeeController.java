package com.allwin.first.controller;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.allwin.first.model.Address;
import com.allwin.first.model.Employee;
import com.allwin.first.model.FullEmployee;
import com.allwin.first.repo.AddressRepo;
import com.allwin.first.repo.EmployeeRepo;
import com.allwin.first.service.EmployeeService;

@RestController
public class RestEmployeeController {

	@Autowired
	private EmployeeRepo empRepo;
	
	@Autowired
	private AddressRepo addRepo;
	
	@Autowired
	private EmployeeService servRepo;
	
	@GetMapping("restGetEmployees")
	public List<Employee> restGetEmployees() 
	{
		return empRepo.findAll();
	}
	
	@GetMapping("restViewEmployee/{empId}")
	public FullEmployee restViewEmployee(@PathVariable("empId") String empId) 
	{		
		Employee emp = empRepo.findById(empId).orElse(new Employee("","","","","","",""));
		List<Address> addr = servRepo.findAllByEmpIdServ(empId);
		FullEmployee fullEmp = new FullEmployee(emp.getEmpId(), emp.getEmpName(), emp.getEmpGender(), emp.getEmpEmail(), emp.getEmpPhone(), emp.getEmpPosition(), addr);
		
		return fullEmp;
	}
	
	@GetMapping("restAddEmployee/{empId}/{empName}/{empGender}/{empEmail}/{empPhone}/{empPosition}/{addressId}/{street}/{city}/{district}/{state}/{pincode}")
	public String addEmployee(@PathVariable("empId") String empId, @PathVariable("empName") String empName, @PathVariable("empGender") String empGender, @PathVariable("empEmail") String empEmail, @PathVariable("empPhone") String empPhone, @PathVariable("empPosition") String empPosition, @PathVariable("addressId") Integer addressId, @PathVariable("street") String street, @PathVariable("city") String city, @PathVariable("district") String district, @PathVariable("state") String state, @PathVariable("pincode") String pincode) 
	{
		LocalDateTime localDateTime = LocalDateTime.now();
		Employee emp = new Employee(empId, empName, empGender, empEmail, empPhone, empPosition, localDateTime.toString());
		Address addr = new Address(addressId, empId, street, city, state, district, pincode, localDateTime.toString());
		
		empRepo.save(emp);
		addRepo.save(addr);
		return "Employee Added Successfully!";
	}
	
	@GetMapping("restUpdateEmployee/{empId}/{empName}/{empGender}/{empEmail}/{empPhone}/{empPosition}")
	public String restUpdateEmployee(@PathVariable("empId") String empId, @PathVariable("empName") String empName, @PathVariable("empGender") String empGender, @PathVariable("empEmail") String empEmail, @PathVariable("empPhone") String empPhone, @PathVariable("empPosition") String empPosition) 
	{
		LocalDateTime localDateTime = LocalDateTime.now();
		Employee emp = new Employee(empId, empName, empGender, empEmail, empPhone, empPosition, localDateTime.toString());
		
		empRepo.save(emp);
		return "Employee Updated Successfully!";
	}
	
	@GetMapping("restDeleteEmployee/{empId}")
	public String restDeleteEmployee(@PathVariable("empId") String empId) 
	{
		empRepo.deleteById(empId);
		servRepo.deleteAllByEmpIdServ(empId);
		return "Employee Deleted Successfully!";
	}
	
	@GetMapping("restSearchEmployee/{searchText}")
	public List<Employee> restSearchEmployee(@PathVariable("searchText") String searchText) 
	{
		List<Employee> empList = servRepo.searchEmployeeServ(searchText);
		List<Address> addrList = servRepo.searchAddressServ(searchText);
		for(int i=0;i<addrList.size();i++) {
			Employee emp = empRepo.findById(addrList.get(i).getEmpId()).orElse(new Employee("","","","","","",""));
			if(empList.contains(emp) == false) { empList.add(emp); }
		}
		return empList;
	}
	
	@GetMapping("restAddAddress/{empId}/{addressId}/{street}/{city}/{district}/{state}/{pincode}")
	public String restAddAddress(@PathVariable("empId") String empId, @PathVariable("addressId") Integer addressId, @PathVariable("street") String street, @PathVariable("city") String city, @PathVariable("district") String district, @PathVariable("state") String state, @PathVariable("pincode") String pincode) 
	{
		LocalDateTime localDateTime = LocalDateTime.now();
		Address addr = new Address(addressId, empId, street, city, state, district, pincode, localDateTime.toString());
		
		addRepo.save(addr);
		return "Address Added Successfully!";
	}
	
}
