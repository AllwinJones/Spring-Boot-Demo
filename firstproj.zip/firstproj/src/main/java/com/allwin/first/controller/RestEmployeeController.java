package com.allwin.first.controller;

import java.time.LocalDateTime;
//import java.util.HashMap;
import java.util.List;
//import java.util.Map;

import javax.validation.Valid;

//import org.hibernate.Session;
//import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.cache.annotation.Cacheable;
//import org.springframework.cache.annotation.Caching;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.allwin.first.exception.AddAddressException;
import com.allwin.first.exception.AddEmployeeException;
import com.allwin.first.exception.DeleteAddressException;
import com.allwin.first.exception.DeleteEmployeeException;
import com.allwin.first.exception.EmployeeIdAlreadyExistException;
import com.allwin.first.exception.EmployeeNotFoundException;
import com.allwin.first.exception.NoMatchesFoundException;
import com.allwin.first.exception.UpdateEmployeeException;
import com.allwin.first.model.Address;
import com.allwin.first.model.Employee;
import com.allwin.first.model.FullEmployee;
import com.allwin.first.model.Notification;
import com.allwin.first.repo.EmployeeRepo;
import com.allwin.first.service.EmployeeService;

@RestController
public class RestEmployeeController {

	@Autowired
	private EmployeeRepo empRepo;
	
	@Autowired
	private EmployeeService servRepo;
	
	@GetMapping("restGetEmployees")
	public List<Employee> restGetEmployees() 
	{
		return empRepo.findAll();
	}
	
	@GetMapping("restViewEmployee/{empId}")
	public ResponseEntity<?> restViewEmployee(@PathVariable("empId") String empId)
	{		
		try {
			//Thread.sleep(1000*5);
			//Long time1, time2;
			//time1 = System.currentTimeMillis();
			Employee emp = servRepo.findOneByIdServ(empId);
			
			if(emp == null) {
				throw new EmployeeNotFoundException("Employee Not Found !");
			}
			
			List<Address> addr = servRepo.findAllByEmpIdServ(empId);
			FullEmployee fullEmp = new FullEmployee(emp.getEmpId(), emp.getEmpName(), emp.getEmpGender(), emp.getEmpEmail(), emp.getEmpPhone(), emp.getEmpPosition(), addr);
			//time2 = System.currentTimeMillis();
			//System.out.println("Amount of time taken:" + (time2 - time1));
			return new ResponseEntity<FullEmployee>(fullEmp, HttpStatus.OK);
		} catch(EmployeeNotFoundException e) {
			return new ResponseEntity<Notification>(new Notification("Error", e.getMessage()), HttpStatus.BAD_REQUEST);
		} /*catch (InterruptedException e) 
        {
			return new ResponseEntity<String>(e.toString(), HttpStatus.BAD_REQUEST);
        }*/
		
	}
	
	@GetMapping("restAddEmployee")
	public ResponseEntity<?> addEmployee(@Valid @RequestBody Employee employee) 
	{
		try {
			if(servRepo.findOneByIdServ(employee.getEmpId()) != null) {
				throw new EmployeeIdAlreadyExistException("Employee ID Already Exist !");
			}
			LocalDateTime localDateTime = LocalDateTime.now();
			employee.setLastUpdated(localDateTime.toString());
			Employee addedEmp = servRepo.addEmployeeServ(employee);
			
			if(addedEmp == null) {
				throw new AddEmployeeException("Employee not Added !");
			}
			
			return new ResponseEntity<Notification>(new Notification("Success", "Employee Added Successfully !"), HttpStatus.OK);
		} catch(EmployeeIdAlreadyExistException e) {
			return new ResponseEntity<Notification>(new Notification("Error", e.getMessage()), HttpStatus.BAD_REQUEST);
		}
		 catch(AddEmployeeException e) {
			 return new ResponseEntity<Notification>(new Notification("Error", e.getMessage()), HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("restUpdateEmployee")
	public ResponseEntity<?> restUpdateEmployee(@Valid @RequestBody Employee employee) 
	{
		try {
			if(servRepo.findOneByIdServ(employee.getEmpId()) == null) {
				throw new EmployeeNotFoundException("Employee Not Found !");
			}
			
			LocalDateTime localDateTime = LocalDateTime.now();
			employee.setLastUpdated(localDateTime.toString());
			Employee updatedEmp = servRepo.updateEmployeeServ(employee);
			
			if(updatedEmp == null) {
				throw new UpdateEmployeeException("Employee not Updated !");
			}
			
			return new ResponseEntity<Notification>(new Notification("Success", "Employee Updated Successfully !"), HttpStatus.OK);
		} catch(UpdateEmployeeException e) {
			return new ResponseEntity<Notification>(new Notification("Error", e.getMessage()), HttpStatus.BAD_REQUEST);
		} catch(EmployeeNotFoundException e) {
			return new ResponseEntity<Notification>(new Notification("Error", e.getMessage()), HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("restDeleteEmployee/{empId}")
	public ResponseEntity<?> restDeleteEmployee(@PathVariable("empId") String empId) 
	{
		try {
			servRepo.deleteEmployeeServ(empId);
			
			if(empRepo.existsById(empId) == true) {
				throw new DeleteEmployeeException("Employee not Deleted !");
			}
			
			List<Address> addrCount = servRepo.findAllByEmpIdServ(empId);
			int deletedAddr = servRepo.deleteAllByEmpIdServ(empId);
			
			if(addrCount.size() != deletedAddr) {
				throw new DeleteAddressException("Employee address(es) not Deleted !");
			}
			
			return new ResponseEntity<Notification>(new Notification("Success", "Employee Deleted Successfully !"), HttpStatus.OK);
		} catch(DeleteEmployeeException e) {
			return new ResponseEntity<Notification>(new Notification("Error", e.getMessage()), HttpStatus.BAD_REQUEST);
		} catch(DeleteAddressException e) {
			return new ResponseEntity<Notification>(new Notification("Error", e.getMessage()), HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("restSearchEmployee/{searchText}")
	public ResponseEntity<?> restSearchEmployee(@PathVariable("searchText") String searchText) 
	{
		try {
			List<Employee> empList = servRepo.searchEmployeeServ(searchText);
			List<Address> addrList = servRepo.searchAddressServ(searchText);
			
			for(int i=0;i<addrList.size();i++) {
				Employee emp = servRepo.findOneByIdServ(addrList.get(i).getEmpId());
				if(empList.contains(emp) == false) { empList.add(emp); }
			}
			
			if(empList.size() == 0) {
				throw new NoMatchesFoundException("No Match Found !");
			}
			
			return new ResponseEntity<List<Employee>>(empList, HttpStatus.OK);
		} catch(NoMatchesFoundException e) {
			return new ResponseEntity<Notification>(new Notification("Error", e.getMessage()), HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("restAddAddress")
	public ResponseEntity<?> restAddAddress(@Valid @RequestBody Address address) 
	{
		try {
			LocalDateTime localDateTime = LocalDateTime.now();
			address.setLastUpdated(localDateTime.toString());
			Address addedAddr = servRepo.addAddressServ(address);
			
			if(addedAddr == null) {
				throw new AddAddressException("Address not Added !");
			}
			
			return new ResponseEntity<Notification>(new Notification("Success", "Address Added Successfully !"), HttpStatus.OK);
		} catch(AddAddressException e) {
			return new ResponseEntity<Notification>(new Notification("Error", e.getMessage()), HttpStatus.BAD_REQUEST);
		}
	}
	
}
