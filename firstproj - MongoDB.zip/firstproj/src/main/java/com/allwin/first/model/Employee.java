package com.allwin.first.model;

//import javax.persistence.Entity;
//import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

//import org.hibernate.annotations.Cache;
//import org.hibernate.annotations.CacheConcurrencyStrategy;
//import org.springframework.cache.annotation.Cacheable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document
//@Entity
/*@javax.persistence.Cacheable
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)*/
public class Employee {

	//@Id
	@Id
	@NotEmpty(message="Employee ID should not be empty")
	private String empId;
	
	@NotEmpty(message="Name should not be empty")
	@Size(min=3, message="Name should be atleast 3 characters")
	private String empName;
	
	@NotEmpty(message="Gender should not be empty")
	@Size(min=4, max=6, message="Gender should be 4-6 characters")
	private String empGender;
	
	@NotEmpty(message="Email should not be empty")
	@Email(message="Invalid Email format")
	private String empEmail;
	
	@NotEmpty(message="Phone number should not be empty")
	@Size(min=10, max=10, message="Phone number should be 10 characters")
	private String empPhone;
	
	@NotEmpty(message="Position should not be empty")
	@Size(min=4, message="Position should be atleast 4 characters")
	private String empPosition;
	
	private String lastUpdated;
	
}
