package com.allwin.first.repo;

import java.util.List;

//import javax.transaction.Transactional;

//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Modifying;
//import org.springframework.data.jpa.repository.Query;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.allwin.first.model.Address;

/*public interface AddressRepo extends JpaRepository<Address, Integer>{
	
	@Query(value = "SELECT * FROM address WHERE empId = ?1", nativeQuery = true)
	List<Address> findAllByEmpId(String empId);
	
	@Modifying
    @Transactional
	@Query(value = "DELETE FROM address WHERE empId = ?1", nativeQuery = true)
	int deleteAllByEmpId(String empId);
	
	@Query(value = "SELECT * FROM address WHERE street like %?1% or city like %?1% or district like %?1% or state like %?1% or pincode like %?1%", nativeQuery = true)
	List<Address> searchAddress(String searchText);
	
}*/

@Repository
public interface AddressRepo extends MongoRepository<Address, Integer>{
	
	@Query("{ empId:?0 }")
	List<Address> findAllByEmpId(String empId);
	
	@Query(value = "{ empId:?0 }", delete = true)
	int deleteAllByEmpId(String empId);
	
	@Query("{ $or:[ { street:{ $regex:?0, $options: 'i' } }, { city:{ $regex:?0, $options: 'i' } }, { district:{ $regex:?0, $options: 'i' } }, { state:{ $regex:?0, $options: 'i' } }, { pincode:{ $regex:?0, $options: 'i' } } ] }")
	List<Address> searchAddress(String searchText);
	
}
