package com.allwin.first.serviceImpl;

import java.util.List;

//import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.allwin.first.model.Address;
import com.allwin.first.model.Employee;
import com.allwin.first.repo.AddressRepo;
import com.allwin.first.repo.EmployeeRepo;
import com.allwin.first.service.EmployeeService;

@Service("employeeService")
@Transactional
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeRepo empRepo;
	
	@Autowired
	private AddressRepo addRepo;
	
	@Override
	public List<Employee> searchEmployeeServ(String searchText) {
		return empRepo.searchEmployee(searchText);
	}
	
	@Override
	@Cacheable(value="cacheEmpL1", key = "'Address'+#empId")
	//@Caching(cacheable = {@Cacheable(value="cacheEmpL1", key = "'EmployeeInCache'+#empId"), @Cacheable(value="cacheEmpL2", key = "'EmployeeInCache'+#empId") })
	public List<Address> findAllByEmpIdServ(String empId) {
		return addRepo.findAllByEmpId(empId);
	}
	
	@Override
	@CacheEvict(value="cacheEmpL1", key = "'Address'+#empId")
	public int deleteAllByEmpIdServ(String empId) {
		return addRepo.deleteAllByEmpId(empId);
	}
	
	@Override
	public List<Address> searchAddressServ(String searchText) {
		return addRepo.searchAddress(searchText);
	}
	
	@Override
	@Cacheable(value="cacheEmpL1", key = "'Employee'+#empId")
	public Employee findOneByIdServ(String empId) {
		//System.out.println("Database hit");
		return empRepo.findOneById(empId);
	}
	
	@Override
	@CachePut(value="cacheEmpL1", key = "'Employee'+#employee.empId")
	public Employee addEmployeeServ(Employee employee) {
		return empRepo.save(employee);
	}
	
	@Override
	@CachePut(value="cacheEmpL1", key = "'Employee'+#employee.empId")
	public Employee updateEmployeeServ(Employee employee) {
		return empRepo.save(employee);
	}
	
	@Override
	@CacheEvict(value="cacheEmpL1", key = "'Employee'+#empId")
	public int deleteEmployeeServ(String empId) {
		return empRepo.deleteOneById(empId);
	}
	
	@Override
	@CacheEvict(value="cacheEmpL1", key = "'Address'+#address.empId")
	public Address addAddressServ(Address address) {
		return addRepo.save(address);
	}
	
}
